# -*- coding: cp1252 -*-
from Tkinter import *
from PIL import ImageTk , Image
import webbrowser
import random
import time
import datetime
import subprocess

#################################################################################################################################################################################################################################################################################################################

Master = Tk()
Master.title("Java Tutorial")
#Master.state("zoomed")
Master.configure(background="turquoise1")
Master.geometry("+0+0")

#################################################################################################################################################################################################################################################################################################################

img = ImageTk.PhotoImage(Image.open("java_logo.gif"))
panel = Label(Master, image = img)
panel.grid(row=0,column=0,padx=35,columnspan=3,pady=30)

#################################################################################################################################################################################################################################################################################################################

abt1="""Java is a general purpose, high-level programming language developed by Sun Microsystems. The Java programming language was developed by a small team of engineers ,known  
as the Green Team, who initiated the language in 1991. The Java language was originally called OAK, and at the time it was designed for handheld devices
and set-top boxes. Oak was unsuccessful and in 1995 Sun changed the name to Java and modified the language to take advantage of the burgeoning World Wide Web."""

abt2="""Motive:- This tutorial has been prepared for the beginners to help them understand the basic to advanced concepts related to Java Programming language."""

abt3="""Pre-Requisites:- Nothing. This tutorial is designed for beginners with little or no coding experience. No installation is required as we provide an online IDE for testing! """

abt4="""Java is an object-oriented programming language developed by Sun Microsystems and released in 1995 """

abt5="""Java was originally developed by James Gosling at Sun Microsystems (which has since merge into Oracle Corporation)."""

abt6="""Java programs are platform independent which means they can be run on any operating system with any type of processor
                    as long as the Java interpreter is available on that system. """

abt7="""Java code that runs on one platform does not need to be recompiled to run on another platform, it's called write once, run anywhere(WORA)."""

abt8=""""Java Virtual Machine (JVM) executes Java code, but is written in platform specific languages such as C/C++/ASM etc. JVM is not written in
                    Java and hence cannot be platform independent and Java interpreter is actually a part of JVM. """

abt9="""Object Oriented:- In java everything is an Object. Java can be easily expanded since it is based on the Object model."""

abt10="""Platform independent:- C and C++ are platform dependency languages hence the application programs written in one Operating system cannot
        run in any other Operating system, but in platform independence language like Java application programs written in one Operating system
                                                 can able to run on any Operating system."""                                                                                                 
abt11="""Simple:- Java is designed to be easy to learn. If you understand the basic concept of OOP java would be easy to master. """                 

abt12="""Secure:- With Java's secure feature it enables to develop virus-free, tamper-free systems. Authentication techniques are based on public-key encryption."""

abt13="""Architectural-neutral:- Java compiler generates an architecture-neutral object file format which makes the compiled code to be executable
        on many processors, with the presence Java runtime system."""

abt14="""Portable:- Being architectural neutral and having no implementation dependent aspects of the specification makes Java portable.
                   Compiler and Java is written in ANSI C with a clean portability boundary which is a POSIX subset."""

abt15="""Robust:- Java makes an effort to eliminate error prone situations by emphasizing mainly on compile time error checking and runtime checking."""

abt16="""Multi-threaded:- With Java's multi-threaded feature it is possible to write programs that can do many tasks simultaneously. This design
                              feature allows developers to construct smoothly running interactive applications."""                                   

abt17="""Interpreted:- Java byte code is translated on the fly to native machine instructions and is not stored anywhere. The development process
                              is more rapid and analytical since the linking is an incremental and light weight process."""

abt18="""High Performance:- With the use of Just-In-Time compilers Java enables high performance."""                                                   

abt19="""Encapsulation in Java is a mechanism of wrapping the data (variables) and code acting on the data (methods) together as a single unit.
In encapsulation, the variables of a class will be hidden from other classes, and can be accessed only through the methods of their
          current class. Therefore, it is also known as data hiding. To achieve encapsulation in Java:-                                         
          1:- Declare the variables of a class as private.
          2:- Provide public set and get methods to modify and view the variables values."""
abt20="""   Benefits of Encapsulation:-                                                                                                           
                    1:- The fields of a class can be made read-only or write-only.                                                                          
                2:- A class can have total control over what is stored in its fields.                                                                """
#################################################################################################################################################################################################################################################################################################################

def encap():
    window2 = Toplevel()
    window2.geometry("+0+0")
    window2.configure(background="turquoise1")
    Label(window2 , text = "Encapsulation",font="Times 25 bold",padx=10,pady=10).grid(row = 0 , column = 0)
    Label(window2,bg="turquoise1").grid(row=1,column=0)
    Label(window2,text=abt19,padx=20,font="Times 14").grid(row=2,column=0)
    Label(window2,bg="turquoise1").grid(row=3,column=0)
    Button(window2 , text = "Try a Sample Code!!" ,font="Times 15 bold",fg="blue",padx=10,pady=10, command =lambda:webbrowser.open("https://ideone.com/tbeWX4") ).grid(row = 4, column = 0)
    Label(window2,bg="turquoise1").grid(row=5,column=0)
    Label(window2,text=abt20,padx=20,font="Times 14").grid(row=6,column=0)
    Label(window2,bg="turquoise1").grid(row=7,column=0)
    Button(window2 , text="Back" ,font="Times 20 bold",fg="blue2",bd=10,relief="groove",cursor="circle",padx=10,pady=10,command=lambda: window2.destroy()).grid(row=8,column=0)

def intro():
    window3=Toplevel()
    window3.geometry("+0+0")
    window3.configure(background="turquoise1")
    Label(window3, text="Introduction to Java" ,font="Times 25 bold",padx=10,pady=10).grid(row=0,column=0)
    Label(window3,bg="turquoise1").grid(row=1,column=0)
    Label(window3,text=abt4,padx=20,font="Times 14").grid(row=2,column=0)
    Label(window3,bg="turquoise1").grid(row=3,column=0)
    Label(window3,text=abt5,padx=20,font="Times 14").grid(row=4,column=0)
    Label(window3,bg="turquoise1").grid(row=5,column=0)
    Label(window3,text=abt6,padx=20,font="Times 14").grid(row=6,column=0)
    Label(window3,bg="turquoise1").grid(row=7,column=0)
    Label(window3,text=abt7,padx=20,font="Times 14").grid(row=8,column=0)
    Label(window3,bg="turquoise1").grid(row=9,column=0)
    Label(window3,text=abt8,padx=20,font="Times 14").grid(row=10,column=0)
    Label(window3,bg="turquoise1").grid(row=11,column=0)
    Button(window3 , text="Back" ,font="Times 20 bold",fg="blue2",relief="groove",cursor="circle",bd=10,padx=10,pady=10,command=lambda: window3.destroy()).grid(row=12,column=0)

def fcts():
    window4=Toplevel()
    window4.geometry("+0+0")
    window4.configure(background="turquoise1")
    Label(window4, text="Facts about Java" ,font="Times 25 bold",padx=10,pady=10).grid(row=0,column=0)
    Label(window4,bg="turquoise1").grid(row=1,column=0)
    Label(window4,text=abt9,padx=20,font="Times 14").grid(row=2,column=0)
    Label(window4,bg="turquoise1").grid(row=3,column=0)
    Label(window4,text=abt10,padx=20,font="Times 14").grid(row=4,column=0)
    Label(window4,bg="turquoise1").grid(row=5,column=0)
    Label(window4,text=abt11,padx=20,font="Times 14").grid(row=6,column=0)
    Label(window4,bg="turquoise1").grid(row=7,column=0)
    Label(window4,text=abt12,padx=20,font="Times 14").grid(row=8,column=0)
    Label(window4,bg="turquoise1").grid(row=9,column=0)
    Label(window4,text=abt13,padx=20,font="Times 14").grid(row=10,column=0)
    Label(window4,bg="turquoise1").grid(row=11,column=0)
    Label(window4,text=abt14,padx=20,font="Times 14").grid(row=12,column=0)
    Label(window4,bg="turquoise1").grid(row=13,column=0)
    Label(window4,text=abt15,padx=20,font="Times 14").grid(row=14,column=0)
    Label(window4,bg="turquoise1").grid(row=15,column=0)
    Label(window4,text=abt16,padx=20,font="Times 14").grid(row=16,column=0)
    Label(window4,bg="turquoise1").grid(row=17,column=0)
    Label(window4,text=abt17,padx=20,font="Times 14").grid(row=18,column=0)
    Label(window4,bg="turquoise1").grid(row=19,column=0)
    Label(window4,text=abt18,padx=20,font="Times 14").grid(row=20,column=0)
    Button(window4 , text="Back" ,font="Times 20 bold",fg="blue2",relief="groove",cursor="circle",bd=10,padx=10,pady=10,command=lambda: window4.destroy()).grid(row=20,column=1)

def abt_window1():
    window1 = Toplevel()
    window1.configure(background="turquoise1")
    window1.geometry("+0+0")
    B2=Button(window1 , text="Introduction" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: intro())
    B2.grid(row = 0 , column = 0,padx=10,pady=10)
    B2=Button(window1 , text="Facts" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: fcts())
    B2.grid(row = 0 , column = 1,padx=10,pady=10)
    B2=Button(window1 , text="Inheritance" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: inherit())
    B2.grid(row = 0 , column = 2,padx=10,pady=10)
    B2=Button(window1 , text="Arrays" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: inherit())
    B2.grid(row = 0 , column = 3,padx=10,pady=10)
    B2=Button(window1 , text="Strings" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: inherit())
    B2.grid(row = 1 , column = 0,padx=10,pady=10)
    B2=Button(window1 , text="Iteration/Looping" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: inherit())
    B2.grid(row = 1 , column = 1,padx=10,pady=10)
    B2=Button(window1 , text="Decision-Making" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: inherit())
    B2.grid(row = 1 , column = 2,padx=10,pady=10)
    B2=Button(window1 , text="" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: inherit())
    B2.grid(row = 1 , column = 3,padx=10,pady=10)
    B2=Button(window1 , text="Inheritance" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: inherit())
    B2.grid(row = 2 , column = 0,padx=10,pady=10)
    B2=Button(window1 , text="Encapsulation" , font="Times 20 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle" , command = lambda: encap())
    B2.grid(row = 2 , column = 1,padx=10,pady=10)

def abt_window():
    window = Toplevel()
    window.geometry("+0+0")
    window.configure(background="turquoise1")
    window.title("About")
    Label(window, text="ABOUT",font="Times 30 bold").grid(row=0,column=0)
    Label(window,bg="turquoise1").grid(row=1,column=0)
    Label(window,text=abt1,padx=20,font="Times 14").grid(row=2,column=0)
    Label(window,bg="turquoise1").grid(row=3,column=0)
    Label(window,text=abt2,padx=20,font="Times 14").grid(row=4,column=0)
    Label(window,bg="turquoise1").grid(row=5,column=0)
    Label(window,text=abt3,padx=20,font="Times 14").grid(row=6,column=0)
    Label(window,bg="turquoise1").grid(row=7,column=0)
    BE=Button(window , text="Back" , font="Times 25 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle",command=window.destroy)
    BE.grid(row=8,column=0)
    

#################################################################################################################################################################################################################################################################################################################

B1=Button(Master , text="About" , font="Times 25 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle",command=abt_window)
B1.grid(row=1,column=0)
B2=Button(Master , text="I'm in!" , font="Times 25 bold" , fg="blue2" , bd=10  , relief="groove" , cursor="circle",command = abt_window1)
B2.grid(row=1,column=2,pady=30)
localtime=time.asctime(time.localtime(time.time()))
L2=Label(Master, text=localtime, font="Times 25 bold" , fg="blue2")
L2.grid(row=1,column=1)

Master.mainloop()
