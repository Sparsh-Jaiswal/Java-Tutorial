import Tkinter as tk
from PIL import ImageTk,Image

root = tk.Tk()
img = ImageTk.PhotoImage(Image.open("java_logo.gif"))
panel = tk.Label(root, image = img)
panel.grid(row=0,column=1)
root.state("zoomed")
root.mainloop()
